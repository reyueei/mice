﻿var dataString ='<chart manageResize="1" palette="2" caption="Stock Price Monitor : Price and Volume" subCaption="(Updates every 3 seconds) - Random data" numberPrefix="$" SNumberPrefix="$" setAdaptiveYMin="1" setAdaptiveSYMin="1"  xAxisName="Time" showRealTimeValue="1" labelDisplay="Rotate" slantLabels="1" numDisplaySets="20" pYAxisMinValue="29" pYAxisMaxValue="36" sYAxisMinValue="55000" sYAXisMaxValue="60000" sDecimals="0" decimals="2" yaxisValueDecimals="0" sFormatNumberScale="1" canvasBottomMargin="130">\n\
   <categories>\n\
   </categories>\n\
   <dataset seriesName="Price" showValues="0" color="4297C3">\n\
   </dataset>\n\
   <dataset seriesName="Volume" showValues="0" parentYAxis="S" color="D5A255" >\n\
   </dataset>\n\
   <styles>\n\
      <definition>\n\
         <style type="font" name="captionFont" size="14" />\n\
      </definition>\n\
      <application>\n\
         <apply toObject="Realtimevalue" styles="captionFont" />\n\
      </application>\n\
   </styles>\n\
   <trendlines>\n\
	<line parentYAxis="P" startValue="32.7" displayValue="Open" thickness="1" color="0372AB" dashed="1" />\n\
	<line parentYAxis="S" startValue="58300" displayValue="Open" thickness="1" color="DF8600" dashed="1" />\n\
   </trendlines>\n\
</chart>'; 